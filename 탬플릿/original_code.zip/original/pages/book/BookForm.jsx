import React, { useEffect, useState } from 'react'
import Button from '../../components/common/Button'
import Input from '../../components/common/Input'
import styles from './BookForm.module.css'
import axios from 'axios'
import { selectCate } from '../../api/CategoriesApi'
import { insertBook } from '../../api/bookApi'
import Select from '../../components/common/Select'
import Textarea from '../../components/common/Textarea'

const BookForm = () => {
  const[cateList, setCateList] = useState([]);

  useEffect(() => {
    getListData();
  }, [])

  const getListData = async () => {
    const response = await selectCate();
    setCateList(response.data);
  }

  const[bookData, setBookData] = useState ({
    bookTitle : '',
    bookPrice : '',
    author : '',
    bookIntro : '',
    publishDate : '',
    cateNum : '0'
  });

  const [mainImg, setMainImg] = useState(null);
  const [subImgs, setSubImgs] = useState(null);

  const [errors, setErrors] = useState({
    bookTitle : '',
    bookPrice : '',
    publishDate : '',
    cateNum : '',
    author : '',
    bookIntro: ''
  })

  const validateField = () => {
    let isvalid = true;

    const newErrors = {
      bookTitle : '',
      bookPrice : '',
      publishDate : '',
      cateNum : '',
      author : '',
      bookIntro: ''
    }

    if(bookData.bookTitle === ''){
      newErrors.bookTitle = '도서명은 필수 입력입니다.'
      isvalid = false;
    }
    if(bookData.bookTitle.length > 10){
      newErrors.bookTitle = '10글자를 초과할 수 없습니다.'
      isvalid = false;
    }
    if(bookData.bookPrice === ''){
      newErrors.bookPrice = '가격은 필수 입력입니다.'
      isvalid = false;
    }
    if(isNaN(bookData.bookPrice) || Number(bookData.bookPrice) <= 0){
      newErrors.bookPrice = '적합한 데이터가 아닙니다.'
      isvalid = false;
    }
    if(bookData.cateNum === '0'){
      newErrors.cateNum = '카테고리는 필수 선택입니다.'
      isvalid = false;
    }
    if(bookData.publishDate === ''){
      newErrors.publishDate = '출판일은 필수항목입니다.'
      isvalid = false;
    }
    if(bookData.author === ''){
      newErrors.author = '글쓴이를 입력하세요'
      isvalid = false;
    }
    if(bookData.bookIntro.length < 5){
      newErrors.bookIntro = '5글자 이상 적으시오'
      isvalid = false;
    }

    setErrors(newErrors);
    return isvalid;
  }

  const handleBookData = (e) => {
    setBookData( (prev) => {
      return{
        ...prev,
        [e.target.name] : e.target.value
      }
    })

    if(errors[e.target.name]){
      setErrors((prev) => {
        return{
          ...prev,
          [e.target.name] : ''
        }
      })
    }
  }

  const regBook = async () => {
    const isValid = validateField();

    if(!isValid){
      return;
    }

    const regForm = new FormData();
    regForm.append('bookTitle', bookData.bookTitle);
    regForm.append('bookPrice', bookData.bookPrice);
    regForm.append('author', bookData.author);
    regForm.append('bookIntro', bookData.bookIntro);
    regForm.append('publishDate', bookData.publishDate);
    regForm.append('cateNum', bookData.cateNum);
    regForm.append('mainImg', mainImg);

    for(const e of subImgs){
      regForm.append('subImgs', e);
    }

    const response = await insertBook(regForm);

    if(response.status == 201){
      alert('등록 성공')
      setBookData({
        bookTitle : '',
        bookPrice : '',
        author : '',
        bookIntro : '',
        publishDate : '',
        cateNum : '0'
      });
    }else{
      alert('등록 실패')
    }
  }

  return (
    <div className={styles.container}>

      <div>
        <p>Book Category</p>
        <Select 
          name='cateNum'
          value={bookData.cateNum}
          onChange={e => handleBookData(e)}>
          <option value='0'>카테고리 선택</option>
          {
            cateList.map( (cate, i) => {
              return(
                <option key={i} value={cate.cateNum}>{cate.cateName}</option>
              )
            })
          }
        </Select>
        {errors.cateNum && <p className='error'>{errors.cateNum}</p>}
      </div>

      <div>
        <p>Book Title</p>
        <Input 
          name='bookTitle'
          value={bookData.bookTitle}
          onChange={e => handleBookData(e)}
        />
        {errors.bookTitle && <p className='error'>{errors.bookTitle}</p>}
      </div>

      <div>
        <div>
          <p>Price</p>
          <Input
            name='bookPrice'
            value={bookData.bookPrice}
            onChange={e => handleBookData(e)}
          />
          {errors.bookPrice && <p className='error'>{errors.bookPrice}</p>}
        </div>
        <div>
          <p>Author</p>
          <Input
            name='author'
            value={bookData.author}
            onChange={e => handleBookData(e)}
          />
          {errors.author && <p className='error'>{errors.author}</p>}
        </div>
      </div>

      <div>
        <p>Introduce</p>
        <Textarea 
          cols={20} rows={5}
          name='bookIntro'
          value={bookData.bookIntro}
          onChange={e => handleBookData(e)}>
        </Textarea>
          {errors.bookIntro && <p className='error'>{errors.bookIntro}</p>}
      </div>

      <div>
        <p>Publish Date</p>
        <Input
            type='date'
            name='publishDate'
            value={bookData.publishDate}
            onChange={e => handleBookData(e)}
          />
          {errors.publishDate && <p className='error'>{errors.publishDate}</p>}
      </div>

      <div>
        <input type="file" 
          onChange={e => {
            console.log(e.target.files)
            console.log(e.target.files[0])
            setMainImg(e.target.files[0])
          }}
        />
      </div>
      <div>
        <input 
          type="file"
          multiple={true}
          onChange={e => {
            console.log(e.target.files);
            for(let i = 0; i < e.target.files.length; i++){
              console.log(e.target.files[i].name)
            }

            const fileArr = [];
            for(let i = 0; i < e.target.files.length; i++){
              fileArr.push(e.target.files[i]);
            }

            setSubImgs(fileArr);
          }}
        />
      </div>

      <div>
        <Button title='도서 등록' onClick={regBook}/>
      </div>
    </div>
  )
}

export default BookForm;
