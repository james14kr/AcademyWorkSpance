import React, { useState } from 'react'
import Input from '../../components/common/Input'
import Button from '../../components/common/Button'
import styles from './Login.module.css'
import { login } from '../../api/loginApi'
import { useNavigate } from 'react-router-dom'

const Login = ({setLoginInfo}) => {

  const nav = useNavigate();

  const [loginData, setLoginData] = useState({
    memEmail : '',
    memPw : ''
  })

  const handleLoginData = e => {
    setLoginData({
      ...loginData,
      [e.target.name] : e.target.value
    })
  }

  const goLogin = async() => {
    const response = await login(loginData);
    if(response.data !== ''){
      alert("로그인 성공")

      const loginInfo = {
        memEmail : response.data.memEmail,
        memName : response.data.memName,
        memRole : response.data.memRole
      } 

      sessionStorage.setItem('loginInfo', JSON.stringify(loginInfo));
      setLoginInfo(loginInfo);

      if(loginInfo.memRole === 'MANAGER'){
        nav('/manage/book-form')
      }else{
        nav('/');
      }

    }else{
      alert('아이디 및 비밀번호를 확인하세요')
      setLoginData({
        memEmail : '',
        memPw : '',
      });
    }
  }

  return (
    <div className={styles.container}>
      <div className={styles.loginForm}>
        <div>
          <Input 
            placeholder='Input Your Id' 
            name='memEmail' 
            value={loginData.memEmail}
            onChange={handleLoginData}/>
        </div>
        <div>
          <Input 
            placeholder='Input your Password' 
            name='memPw' value={loginData.memPw} 
            onChange={handleLoginData} 
            type='password' 
            onKeyDown={e => {
              if(e.key === 'Enter'){
                goLogin();
              }
            }}
            />
        </div>
        <div> 
          <Button title='로그인' size='medium' onClick={goLogin}/>
        </div>
      </div>
    </div>
  )
}

export default Login
